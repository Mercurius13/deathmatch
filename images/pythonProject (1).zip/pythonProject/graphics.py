import pygame
from turns import Battle
import time
import random

battle = Battle()

# Initialize the Pygame library
pygame.init()

# Pygame screen setup
screen = pygame.display.set_mode((1024, 640), pygame.RESIZABLE)
pygame.display.set_caption("Dice Game")
running = True
stage = "main_menu"

clock = pygame.time.Clock()

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# Load the loading screen image
screen.fill((0, 0, 0))
image = pygame.image.load("images/loading_screen.jpg").convert()
image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
screen.blit(image, (0, 0))
pygame.display.flip()
pygame.time.wait(3000)

# Clear the loading screen
screen.fill((0, 0, 0))
pygame.display.flip()

# Initialize player list and font
player_list = []
font = pygame.font.Font(None, 40)
dice_list = [("black", 20), ("black", 20)]


def display_player_dice(color="", number=0):
    if battle.current_player == battle.one_player:
        if color == "" and number == 0:
            image = pygame.image.load(f"images/{dice_list[0][0]}_dice/dice_{dice_list[0][1]}.png").convert()
            image = pygame.transform.scale(image, (screen.get_width() * 0.25, screen.get_height() * 0.25))
            screen.blit(image, (screen.get_width() * 0.75, screen.get_height() * 0.75))
        else:
            image = pygame.image.load(f"images/{color}_dice/dice_{number}.png").convert()
            image = pygame.transform.scale(image, (screen.get_width() * 0.25, screen.get_height() * 0.25))
            screen.blit(image, (screen.get_width() * 0.75, screen.get_height() * 0.75))
            dice_list[0] = (color, number)
    else:
        if color == "" and number == 0:
            image = pygame.image.load(f"images/{dice_list[1][0]}_dice/dice_{dice_list[1][1]}.png").convert()
            image = pygame.transform.scale(image, (screen.get_width() * 0.25, screen.get_height() * 0.25))
            screen.blit(image, (0, 0))
        else:
            image = pygame.image.load(f"images/{color}_dice/dice_{number}.png").convert()
            image = pygame.transform.scale(image, (screen.get_width() * 0.25, screen.get_height() * 0.25))
            screen.blit(image, (0, 0))
            dice_list[1] = (color, number)


# Function to display text on the screen
def display_text(tup):
    image = pygame.image.load("images/fight_bg.jpg").convert()
    image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
    screen.blit(image, (0, 0))

    image_character_1 = pygame.image.load(f"images/{battle.one_player.name}.png").convert()
    image_character_1 = pygame.transform.scale(image_character_1,
                                               (screen.get_width() * 0.225, screen.get_height() * 0.4))
    screen.blit(image_character_1, (0, screen.get_height() * 0.6))

    image_character_2 = pygame.image.load(f"images/{battle.two_player.name}.png").convert()
    image_character_2 = pygame.transform.scale(image_character_2,
                                               (screen.get_width() * 0.225, screen.get_height() * 0.4))
    screen.blit(image_character_2, (screen.get_width() * 0.775, 0))

    # display text at the bottom of the screen for player 1's health
    font = pygame.font.Font(None, 40)
    text = font.render(f"{battle.one_player.name} Health: {battle.one_player.health}", 1, WHITE)
    text_rect = text.get_rect(center=(screen.get_width() / 2, screen.get_height() - 50))
    screen.blit(text, text_rect)

    # display text at the top of the screen for player 2's health
    text = font.render(f"{battle.two_player.name} Health: {battle.two_player.health}", 1, WHITE)
    text_rect = text.get_rect(center=(screen.get_width() / 2, 50))
    screen.blit(text, text_rect)

    display_player_dice()

    text, pause = tup

    text = font.render(text, True, WHITE)
    text_rect = text.get_rect(center=(screen.get_width() / 2, screen.get_height() / 2))
    screen.blit(text, text_rect)

    pygame.display.flip()
    time.sleep(pause)


# Function to create and manage buttons
def create_and_manage_buttons(buttons):
    image = pygame.image.load("images/fight_bg.jpg").convert()
    image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
    screen.blit(image, (0, 0))

    image_character_1 = pygame.image.load(f"images/{battle.one_player.name}.png").convert()
    image_character_1 = pygame.transform.scale(image_character_1,
                                               (screen.get_width() * 0.225, screen.get_height() * 0.4))
    screen.blit(image_character_1, (0, screen.get_height() * 0.6))

    image_character_2 = pygame.image.load(f"images/{battle.two_player.name}.png").convert()
    image_character_2 = pygame.transform.scale(image_character_2,
                                               (screen.get_width() * 0.225, screen.get_height() * 0.4))
    screen.blit(image_character_2, (screen.get_width() * 0.775, 0))

    # display text at the bottom of the screen for player 1's health
    font = pygame.font.Font(None, 40)
    text = font.render(f"{battle.one_player.name} Health: {battle.one_player.health}", 1, WHITE)
    text_rect = text.get_rect(center=(screen.get_width() / 2, screen.get_height() - 50))
    screen.blit(text, text_rect)

    # display text at the top of the screen for player 2's health
    text = font.render(f"{battle.two_player.name} Health: {battle.two_player.health}", 1, WHITE)
    text_rect = text.get_rect(center=(screen.get_width() / 2, 50))
    screen.blit(text, text_rect)

    display_player_dice()

    button_rects = []
    button_texts = []

    for button in buttons[:-1]:
        button_rect = pygame.Rect(screen.get_width() / 2 - 100, len(button_rects) * 60 + 225, 200, 50)
        button_rects.append(button_rect)

        if button == "blue":
            pygame.draw.rect(screen, BLUE, button_rect)
        elif button == "red":
            pygame.draw.rect(screen, RED, button_rect)
        elif button == "green":
            pygame.draw.rect(screen, GREEN, button_rect)
        else:
            pygame.draw.rect(screen, WHITE, button_rect)

        text = font.render(button.capitalize(), True, BLACK)
        text_rect = text.get_rect(center=button_rect.center)
        screen.blit(text, text_rect)
        button_texts.append(button)

    clicked_buttons = set()

    while len(clicked_buttons) < buttons[-1]:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for button_rect in button_rects:
                    if button_rect.collidepoint(event.pos):
                        clicked_buttons.add(button_texts[button_rects.index(button_rect)])

        pygame.display.flip()

        if len(clicked_buttons) == 2:
            break

    return list(clicked_buttons)


# Main game loop
while running:
    def game_loop():
        pass

        # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT or event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if stage == "main_menu":
                if button_rect_start.collidepoint(event.pos):
                    stage = "game1"
                    screen.fill((0, 0, 0))
                elif button_rect_info.collidepoint(event.pos):
                    stage = "info"
                    print(stage)
                    screen.fill((0, 0, 0))
                elif button_rect_master.collidepoint(event.pos):
                    stage = "stats"
                    print(stage)
                    screen.fill((0, 0, 0))

            elif stage.startswith("game") and stage != "game_loop":
                if button_rect_rogue.collidepoint(event.pos):
                    player_list.append("rogue")
                    screen.fill((0, 0, 0))
                    stage = "game2"
                elif button_rect_lancelot.collidepoint(event.pos):
                    player_list.append("lancelot")
                    screen.fill((0, 0, 0))
                    stage = "game2"
                elif button_rect_master.collidepoint(event.pos):
                    player_list.append("master")
                    screen.fill((0, 0, 0))
                    stage = "game2"
                if len(player_list) == 2:
                    battle.character_select(player_list[0], player_list[1])
                    stage = "game_loop"
                    battle.turns()

        elif stage == "main_menu":
            image = pygame.image.load("images/main_menu_background.jpg").convert()
            image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
            screen.blit(image, (0, 0))
            pygame.display.flip()
            font = pygame.font.Font(None, 40)

            button_rect_start = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 - 100, 200, 50)
            pygame.draw.rect(screen, RED, button_rect_start, 0, 9)
            text = font.render("Start Game", True, BLACK)
            text_rect = text.get_rect(center=button_rect_start.center)
            screen.blit(text, text_rect)

            button_rect_info = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 - 25, 200, 50)
            pygame.draw.rect(screen, GREEN, button_rect_info, 0, 9)
            text = font.render("How To Play", True, BLACK)
            text_rect = text.get_rect(center=button_rect_info.center)
            screen.blit(text, text_rect)

            button_rect_master = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 + 50, 200, 50)
            pygame.draw.rect(screen, BLUE, button_rect_master, 0, 9)
            text = font.render("Statistics", True, BLACK)
            text_rect = text.get_rect(center=button_rect_master.center)
            screen.blit(text, text_rect)

            pygame.display.update([button_rect_start, button_rect_info, button_rect_master])

        elif stage == "game1":
            image = pygame.image.load("images/main_menu_background.jpg").convert()
            image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
            screen.blit(image, (0, 0))
            pygame.display.flip()
            font = pygame.font.Font(None, 40)

            text = font.render("Player 1: Choose your character", 1, (255, 255, 255))
            text_rect = text.get_rect(center=(screen.get_width() / 2, screen.get_height() / 2 - 150))
            screen.blit(text, text_rect)

            button_rect_rogue = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 - 75, 200, 50)
            pygame.draw.rect(screen, RED, button_rect_rogue, 0, 9)
            text = font.render("Rogue", True, BLACK)
            text_rect = text.get_rect(center=button_rect_rogue.center)
            screen.blit(text, text_rect)

            button_rect_lancelot = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 - 0, 200, 50)
            pygame.draw.rect(screen, BLUE, button_rect_lancelot, 0, 9)
            text = font.render("Lancelot", True, BLACK)
            text_rect = text.get_rect(center=button_rect_lancelot.center)
            screen.blit(text, text_rect)

            button_rect_master = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 + 75, 200, 50)
            pygame.draw.rect(screen, GREEN, button_rect_master, 0, 9)
            text = font.render("Master", True, BLACK)
            text_rect = text.get_rect(center=button_rect_master.center)
            screen.blit(text, text_rect)

            pygame.display.flip()

        elif stage == "game2":
            image = pygame.image.load("images/main_menu_background.jpg").convert()
            image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
            screen.blit(image, (0, 0))
            pygame.display.flip()
            font = pygame.font.Font(None, 40)

            text = font.render("Player 2: Choose your character", 1, (255, 255, 255))
            text_rect = text.get_rect(center=(screen.get_width() / 2, screen.get_height() / 2 - 150))
            screen.blit(text, text_rect)

            button_rect_rogue = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 - 75, 200, 50)
            pygame.draw.rect(screen, RED, button_rect_rogue, 0, 9)
            text = font.render("Rogue", True, BLACK)
            text_rect = text.get_rect(center=button_rect_rogue.center)
            screen.blit(text, text_rect)

            button_rect_lancelot = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 - 0, 200, 50)
            pygame.draw.rect(screen, BLUE, button_rect_lancelot, 0, 9)
            text = font.render("Lancelot", True, BLACK)
            text_rect = text.get_rect(center=button_rect_lancelot.center)
            screen.blit(text, text_rect)

            button_rect_master = pygame.Rect(screen.get_width() / 2 - 100, screen.get_height() / 2 + 75, 200, 50)
            pygame.draw.rect(screen, GREEN, button_rect_master, 0, 9)
            text = font.render("Master", True, BLACK)
            text_rect = text.get_rect(center=button_rect_master.center)
            screen.blit(text, text_rect)

            pygame.display.flip()

        elif stage == "game_loop":
            image = pygame.image.load("images/fight_bg.jpg").convert()
            image = pygame.transform.scale(image, (screen.get_width(), screen.get_height()))
            screen.blit(image, (0, 0))

            image_character_1 = pygame.image.load(f"images/{battle.one_player.name}.png").convert()
            image_character_1 = pygame.transform.scale(image_character_1,
                                                       (screen.get_width() * 0.225, screen.get_height() * 0.4))
            screen.blit(image_character_1, (0, screen.get_height() * 0.6))

            image_character_2 = pygame.image.load(f"images/{battle.two_player.name}.png").convert()
            image_character_2 = pygame.transform.scale(image_character_2,
                                                       (screen.get_width() * 0.225, screen.get_height() * 0.4))
            screen.blit(image_character_2, (screen.get_width() * 0.775, 0))

            # display text at the bottom of the screen for player 1's health
            font = pygame.font.Font(None, 40)
            text = font.render(f"{battle.one_player.name} Health: {battle.one_player.health}", 1, WHITE)
            text_rect = text.get_rect(center=(screen.get_width() / 2, screen.get_height() - 50))
            screen.blit(text, text_rect)

            # display text at the top of the screen for player 2's health
            text = font.render(f"{battle.two_player.name} Health: {battle.two_player.health}", 1, WHITE)
            text_rect = text.get_rect(center=(screen.get_width() / 2, 50))
            screen.blit(text, text_rect)

            pygame.display.flip()

        clock.tick(60)

# Quit Pygame
pygame.quit()