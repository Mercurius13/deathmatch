from rogue import *
from graphics import username_1
from graphics import create_and_manage_buttons
from graphics import display_text
import time


def __init__(self, name):
    self.health = 50
    self.enemy_health = 0
    self.max_health = 50
    self.attack = 0
    self.shielding = 0
    self.healing = 0
    self.drain_attack = 0
    self.enemy_attack = 0
    self.enemy_drain_attack = 0
    self.rgb = ''
    self.action = ''
    self.blood_pact_looplock = False
    self.blood_pact_suicide = False
    self.tourniquet_looplock = False
    self.name = name
    self.percentage = 1
    self.x = 0


def reset_cooldowns(self):
    self.blood_pact_looplock = False
    self.tourniquet_looplock = False


def regen_aux(self):
    pass


display_text(("WELCOME TO DEATHMATCH!"))
time.sleep(1)
player1 = username_1
time.sleep(0.5)
player2 = username_1 + " but cooler"
time.sleep(0.5)
one_player = Rogue(username_1)
two_player = Rogue("AI")
display_text(("FLIPPING A COIN...", 1.5))
time.sleep(1.5)
display_text((f"HEADS! {player1} starts first!", 1))
display_text((
    f"Hello {one_player.name}! This ragamuffin here thinks they're cooler than you... how about we show them what's what?",
    5))
display_text((f"You have 50 Health. Enemy attacks will only take effect after your turn."))
time.sleep(5)
display_text((f"If your Health reaches 0, you lose and that scoundrel will be cooler than you."))
time.sleep(5)
display_text((f"To win, you must reduce your enemy's health to 0!"))
time.sleep(5)
display_text((f"The character class ROGUE uses three types of die. Red, Blue and Green."))
time.sleep(5)
display_text((f"Red die are used for ATTACKING. Blue die are used for SHIELDING. Green die are used for HEALING."))
time.sleep(5)
display_text((f"ROGUE can throw two die, but not two of the same colour."))
time.sleep(5)
display_text((f"Since you are starting first, lets throw a red and green dice to attack."))
time.sleep(5)
choose_rgb_r1()


def attack_r1(self):
    if (create_and_manage_buttons(["cleave", "riposte", "blood pact", 1])[0]) == "cleave":
        from graphics import display_text
        from graphics import display_player_dice
        if self.x = 1:
            number = 16
        else:
            number = 20
        time.sleep(1)
        display_player_dice(self.rgb, number)
        display_text((f"You got {number}!", 2))
        if number >= 15:
            self.attack += int((int((number * 1.5) // 1) * self.percentage) // 1)
        else:
            self.attack += int((number * self.percentage) // 1)
        if self.percentage != 1:
            self.percentage = 1
        time.sleep(0.5)
        display_text((f"Your attack is now {self.attack}.", 2))
        self.x = 0
    if (create_and_manage_buttons(["cleave", "riposte", "blood pact", 1])[0]) == "riposte":
        display_text(
            (f"You are not being attacked, hence Riposte is not a good option. Try using Cleave or Blood Pact instead."))
        time.sleep(5)
        attack_r1()
        pass
    if (create_and_manage_buttons(["cleave", "riposte", "blood pact", 1])[0]) == "blood pact":
        from graphics import display_text
        from graphics import display_player_dice
        # Self-Attack, Double next Attack, throw R
        if not self.blood_pact_looplock:
            self.blood_pact_looplock = True
            number = 3
            time.sleep(1)
            display_player_dice(self.rgb, number)
            display_text((f"You got {number}!", 2))
            self.health -= number
            if self.health <= 0:
                self.blood_pact_suicide = True
                pass
            time.sleep(0.5)
            display_text((f"Your health is now {self.health}.", 2))
            time.sleep(0.5)
            display_text(("Next attack is doubled!", 2))
            self.percentage *= 2
            time.sleep(0.5)
            display_text(("Rolling a red dice...", 2))
            self.x = 1
            self.attack_r1()
        else:
            time.sleep(0.5)
            display_text(("You can only use this action once per turn!", 2))
            self.attack_r1()
            pass


def choose_rgb_r1(self):
    racism = create_and_manage_buttons(["blue", "red", "green", 2])
    if "blue" in racism:
        display_text((f"Blue die are used for SHIELDING. You are not being attacked."))
        time.sleep(3)
        display_text((f"Since you are starting first, lets throw a red and green dice to attack."))
        time.sleep(2)
        self.choose_rgb_r1()
        pass
    if "red" in racism:
        display_text((f"Cleave is a basic attack. However if you roll 15 or above, your damage gets multiplied by 1.5."))
        time.sleep(5)
        display_text((f"Riposte is a good action to counter enemy attack. You block, and if all the damage is blocked, you attack. However if all the damage is not blocked, you throw a green dice."))
        time.sleep(10)
        display_text((f"Blood Pact is a risky move. You roll a dice to deal damage to yourself, but you deal twice the damage to the enemy on your next attack. Furthermore, you roll a second red dice. Do note that you cannot use Blood Pact twice in the same turn."))
        time.sleep(15)
        display_text((f"We have a lot of health to spare, so we can use Blood Pact. However if you want to play it safe and not lose health, feel free to use Cleave."))
        self.attack_r1()
    if "green" in racism and not self.blood_pact_suicide:
        choose_rgb("green")
        choose_action(create_and_manage_buttons(["tourniquet", "drain", 1])[0])
