from graphics import username_1, username_2
from rogue import *
from lancelot import *
from master import *
import time


class Battle:
    def __init__(self):
        self.one_player = None
        self.two_player = None
        self.current_player = None
        self.next_player = None
        self.p1_round_count = 0
        self.p2_round_count = -0.5
        self.p1_rogue_max_damage = 0
        self.p1_lancelot_max_damage = 0
        self.p1_master_max_damage = 0
        self.p2_rogue_max_damage = 0
        self.p2_lancelot_max_damage = 0
        self.p2_master_max_damage = 0
        self.d = 0

    def character_select(self, player1, player2):
        from graphics import username_1, username_2
        if player1 == "rogue":
            self.one_player = Rogue(username_1)
        elif player1 == "lancelot":
            self.one_player = Lancelot(username_1)
        elif player1 == "master":
            self.one_player = Master(username_1)

        if player2 == "rogue":
            self.two_player = Rogue(username_2)
        elif player2 == "lancelot":
            self.two_player = Lancelot(username_2)
        elif player2 == "master":
            self.two_player = Master(username_2)

    def calculation(self):
        from graphics import display_text
        self.d = 0
        if self.one_player.preservation_trigger:
            if self.two_player.attack > 75:
                self.two_player.attack = 75
                self.two_player.burn = self.two_player.burn.clear()
                self.two_player.bleed = self.two_player.bleed.clear()
                self.two_player.poison = self.two_player.poison.clear()
                self.two_player.stun = False
                self.two_player.temporary_attack_decrease = 0
                self.two_player.temporary_defence_decrease = 0
                self.two_player.temporary_healing_decrease = 0
        if not self.two_player.stun and not self.one_player.dodge_trigger:
            display_text((f"{self.one_player.name}'s turn!", 2))
            self.one_player.choose_die()
        self.d = self.one_player.attack + self.one_player.drain_attack + self.one_player.burn[0][0] + self.one_player.bleed[0][0] + self.one_player.poison[0][0]
        self.one_player.regen_aux()
        if self.two_player.temporary_attack_decrease > 0:
            self.one_player.attack -= self.two_player.temporary_attack_decrease
            self.two_player.temporary_attack_decrease = 0
        if self.two_player.temporary_defense_decrease > 0:
            self.one_player.shielding -= self.two_player.temporary_defence_decrease
            self.two_player.temporary_defence_decrease = 0
        if self.two_player.temporary_healing_decrease > 0:
            self.one_player.healing -= self.two_player.temporary_healing_decrease
            self.two_player.temporary_healing_decrease = 0
        self.one_player.health += self.one_player.healing
        for i in self.two_player.burn:
            self.two_player.attack += i[0]
        for i in self.two_player.bleed:
            self.two_player.attack += i[0]
        for i in self.two_player.poison:
            self.two_player.attack += i[0]
        if self.one_player.shielding > self.two_player.attack:
            self.one_player.shielding -= self.two_player.attack
            self.two_player.attack = 0
        else:
            self.one_player.health += (self.one_player.shielding - self.two_player.attack)
            self.two_player.attack = 0
        if self.one_player.shielding > self.two_player.drain_attack:
            self.one_player.shielding -= self.two_player.drain_attack
            self.two_player.drain_attack = 0
        else:
            self.one_player.health += (self.one_player.shielding - self.two_player.drain_attack)
            self.two_player.health += self.two_player.drain_attack
            self.two_player.drain_attack = 0
        self.one_player.enemy_attack = 0
        self.two_player.enemy_attack = self.one_player.attack
        self.one_player.is_enemy_attacking = False
        self.one_player.shielding = 0
        self.one_player.healing = 0
        if self.one_player.health > self.one_player.max_health:
            self.one_player.health = self.one_player.max_health
        if not self.one_player.dodge_trigger and not self.one_player.stun:
            display_text((f"Health of {self.two_player.name}: {self.two_player.health}/{self.two_player.max_health}", 2))
            display_text((f"Health of {self.one_player.name}: {self.one_player.health}/{self.one_player.max_health}", 2))
        if self.one_player.dodge_trigger:
            self.one_player.dodge_trigger = False
        if self.two_player.stun_duration == 0:
            self.two_player.stun = False
        if self.one_player.attack > 0:
            self.two_player.is_enemy_attacking = True
        self.two_player.reset_cooldowns()

    def who_starts(self):
        from graphics import display_text
        display_text(("FLIPPING A COIN...", 1.5))
        if self.one_player.max_health > self.two_player.max_health:
            self.one_player, self.two_player = self.two_player, self.one_player
            display_text((f"TAILS! {self.two_player.name} starts first!", 1))
            self.current_player = self.two_player
            self.next_player = self.one_player
        elif self.one_player.max_health == self.two_player.max_health:
            coin_flip = random.choice([f"HEADS! {self.one_player.name} starts first!",
                                       f"TAILS! {self.two_player.name} starts first!"])
            display_text((coin_flip, 1))
            if "TAILS!" in coin_flip:
                self.one_player, self.two_player = self.two_player, self.one_player
                self.current_player = self.one_player
                self.next_player = self.two_player
        else:
            display_text((f"HEADS! {username_1} starts first!", 1))
            self.current_player = self.one_player
            self.next_player = self.two_player

    def turns(self):
        from graphics import display_text
        self.who_starts()
        one_player = self.current_player
        two_player = self.next_player
        while self.one_player.health > 0 and self.two_player.health > 0:
            self.p1_round_count += 0.5
            self.p2_round_count += 0.5
            self.calculation(one_player, two_player)
            if self.one_player == Rogue(username_1):
                if self.p1_rogue_max_damage < self.d:
                    self.p1_rogue_max_damage = self.d
            elif self.one_player == Lancelot(username_1):
                if self.p1_lancelot_max_damage < self.d:
                    self.p1_lancelot_max_damage = self.d
            elif self.one_player == Master(username_1):
                if self.p1_master_max_damage < self.d:
                    self.p1_master_max_damage = self.d
            if self.two_player == Rogue(username_1):
                if self.p2_rogue_max_damage < self.d:
                    self.p2_rogue_max_damage = self.d
            elif self.two_player == Lancelot(username_1):
                if self.p2_lancelot_max_damage < self.d:
                    self.p2_lancelot_max_damage = self.d
            elif self.two_player == Master(username_1):
                if self.p2_master_max_damage < self.d:
                    self.p2_master_max_damage = self.d
            if self.one_player == Rogue(username_2):
                if self.p2_rogue_max_damage < self.d:
                    self.p2_rogue_max_damage = self.d
            elif self.one_player == Lancelot(username_2):
                if self.p2_lancelot_max_damage < self.d:
                    self.p2_lancelot_max_damage = self.d
            elif self.one_player == Master(username_2):
                if self.p2_master_max_damage < self.d:
                    self.p2_master_max_damage = self.d
            if self.two_player == Rogue(username_2):
                if self.p1_rogue_max_damage < self.d:
                    self.p1_rogue_max_damage = self.d
            elif self.two_player == Lancelot(username_2):
                if self.p1_lancelot_max_damage < self.d:
                    self.p1_lancelot_max_damage = self.d
            elif self.two_player == Master(username_2):
                if self.p1_master_max_damage < self.d:
                    self.p1_master_max_damage = self.d
            x = one_player
            one_player = two_player
            two_player = x
        self.p1_round_count = self.p1_round_count // 1
        self.p2_round_count = self.p2_round_count // 1
        if self.one_player.health > self.two_player.health:
            display_text((f"{self.one_player.name.upper()} WINS!", 2))
        else:
            display_text((f"{self.two_player.name.upper()} WINS!", 2))
